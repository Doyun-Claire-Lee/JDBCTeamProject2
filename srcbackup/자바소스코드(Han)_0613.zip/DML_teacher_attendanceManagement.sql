/*** project_test_tblattendanceManagement_teacher.java ***/

/*교사가 강의한 과정에 한해 선택하는 경우 모든 교육생의 출결을 조회할 수 있어야 한다.*/
-- procteacherAttendance(teacherNum)
-- 지금 현재
select * from tbladmin;
select * from tblcourseHistory order by num; --num 312개
select * from tblattendance where status = '조퇴' order by num ; --num이 10개
select * from tblopenCourse;
select * from tblteacher;
select * from tblallCourse;
select * from tblstudent;
desc tblattendance; 
desc tblcourseHistory;

create or replace view vwteacherAttendance
as 
select o.num as "openCourseNum",o.allCourseNum,(select name from tblallCourse where o.allCourseNum = num) as "subject name",t.name as "teacher name", o.teacherNum from tblopenCourse o
        inner join tblteacher t
            on o.teacherNum = t.num 
               where o.status <> 1 and t.deletestatus <> 1
                 order by allCourseNum ; 

create or replace PROCEDURE procteacherAttendance(
    pnum tblopenCourse.num%type,
    pteacherNum tblopenCourse.teacherNum%type,
    presult out sys_refcursor
)
is
begin
open presult for 
  select o.num as "openCourseNum",s.name as "studentName", t.name "teacherName", o.startDate || '~' || o.endDate as "coursePeriod", h.status as "courseStatus", a.status as "attendanceStatus", to_char(a.enterTime,'yyyy-mm-dd hh24:mi:ss') as "enterTime",
  to_char(a.outTime,'yyyy-mm-dd hh24:mi:ss') as "outTime", o.allCourseNum, o.teacherNum
     from tblstudent s
        inner join tblcourseHistory h
            on h.studentNum = s.num
             inner join tblattendance a 
                 on a.courseHistoryNum = h.num
                    inner join tblopenCourse o
                        on h.openCourseNum = o.num
                            inner join tblteacher t
                                on t.num = o.teacherNum
                                     where o.num = pnum and o.teacherNum = pteacherNum and o.status <> 1 and h.status <> '수료' and s.deletestatus <> 1 and h.deletestatus <> 1
                                        and t.deletestatus <> 1;
                                          
end procteacherAttendance;

--select * from tblattendance a
--        inner join tblcourseHistory h
--             on h.num = a.courseHistoryNum ;

/*출결 현황을 기간별(년, 월, 일) 조회할 수 있어야 한다.*/
-- procteacherAttendance1()
select * from tblattendance;
select * from tblCourseHistory;
select* from tblopencourse;
select * from tblstudent;
-- 년 
create or replace PROCEDURE procteacherAttendance1(
    presult out sys_refcursor,
    pyear varchar2,
    pteacherNum number
)
is
begin
open presult for 
    select h.opencoursenum, s.name as "student name", o.teacherNum, to_char(a.enterTime,'yyyy-mm-dd hh24:mi:ss') as "enterTime", to_char(a.outTime,'yyyy-mm-dd hh24:mi:ss') as "outTime", a.status as "attendance status",h.status as "course status" 
        from tblattendance a
            inner join tblcourseHistory h
                on h.studentNum = a.num 
                    inner join tblstudent s
                        on s.num = h.studentnum
                            inner join tblopenCourse o
                                on o.num = h.opencoursenum
                                     where to_char(a.enterTime,'yyyy') = 2019 and s.deleteStatus <> 1 and h.status <> '수료' and h.deletestatus <> 1 and o.teacherNum = pteacherNum and o.status <> 1
                                        order by to_char(a.enterTime,'mm'),to_char(a.enterTime,'dd'),a.num;
end procteacherAttendance1;

-- 월(년)

create or replace PROCEDURE procteacherAttendance2(
    presult out sys_refcursor,
    pmonth varchar2,
    pteacherNum number
)
is
begin
open presult for 
      select h.opencoursenum, s.name as "student name", to_char(a.enterTime,'yyyy-mm-dd hh24:mi:ss') as "enterTime", to_char(a.outTime,'yyyy-mm-dd hh24:mi:ss') as "outTime", a.status as "attendance status",h.status as "course status" 
        from tblattendance a
            inner join tblcourseHistory h
                on h.studentNum = a.num 
                    inner join tblstudent s
                        on s.num = h.studentnum
                         inner join tblopenCourse o
                                on o.num = h.opencoursenum
                                     where to_char(a.enterTime,'mm') = pmonth and s.deleteStatus <> 1 and h.status <> '수료' and h.deletestatus <> 1 and o.status <> 1 and o.teacherNum = pteacherNum
                                        order by to_char(a.enterTime,'yyyy'),to_char(a.enterTime,'dd'),a.num;
end procteacherAttendance2;


--일(년,월)
create or replace PROCEDURE procteacherAttendance3(
    presult out sys_refcursor,
    pday varchar2,
    pteacherNum number
)
is
begin
open presult for 
       select h.opencoursenum, s.name as "student name", to_char(a.enterTime,'yyyy-mm-dd hh24:mi:ss') as "enterTime", to_char(a.outTime,'yyyy-mm-dd hh24:mi:ss') as "outTime", a.status as "attendance status",h.status as "course status" 
        from tblattendance a
            inner join tblcourseHistory h
                on h.studentNum = a.num 
                    inner join tblstudent s
                        on s.num = h.studentnum
                             inner join tblopenCourse o
                                    on o.num = h.opencoursenum
                                         where to_char(a.enterTime,'dd') = pday and s.deleteStatus <> 1 and h.status <> '수료' and h.deletestatus <> 1 and o.status <> 1 and o.teacherNum = pteacherNum
                                            order by to_char(a.enterTime,'yy'),to_char(a.enterTime,'mm'),a.num;
end procteacherAttendance3;


/*특정(특정 과정, 특정 인원 -> 학생 이름) 출결 현황을 조회할 수 있어야 한다.*/ 
-- procteacherAttendanceSelect()
select * from tblcourseHistory;


create or replace view vwcourseHistory
as 
select s.name as "student name",s.num as "student num",h.openCourseNum, o.teacherNum from tblstudent s
    inner join tblcourseHistory h
        on s.num = h.studentNum
            inner join tblopenCourse o
                on o.num = h.openCourseNum
                     where h.status <> '수료' and s.deletestatus <> 1 and h.deletestatus <> 1 and o.status <> 1
                         order by s.name,h.openCourseNum;
                         
select * from tblattendance;
select * from tblcoursehistory;
create or replace PROCEDURE procteacherAttendanceSelect(
    presult out sys_refcursor,
    pnum tblopenCourse.num%type,
    pstudentNum tblcourseHistory.studentNum%type,
    pteacherNum number
)
is
begin
open presult for
    select o.num, o.startDate || '~' || o.endDate as "course period", (select name from tblallCourse where num = o.allCourseNum and o.status <> 1) as "course name", to_char(a.entertime,'yyyy-mm-dd hh24:mi:ss') as "enterTime",
    to_char(a.outtime,'yyyy-mm-dd hh24:mi:ss') as "outTime", s.name as "student name"
    from tblopenCourse o
        inner join tblcourseHistory h
            on o.num = h.openCourseNum
                inner join tblattendance a
                    on a.courseHistoryNum = h.num
                        inner join tblstudent s
                            on s.num = h.studentNum
                                where o.num = pnum and h.studentNum = pstudentNum and o.status <> 1 and h.deletestatus <> 1 and s.deletestatus <> 1 and h.status <> '수료' and o.teacherNum = pteacherNum;
end procteacherAttendanceSelect;
select * from tblopenCourse;    

--select o.num, o.startDate || '~' || o.endDate as "course period", (select name from tblallCourse where num = o.allCourseNum and o.status <> 1) as "course name", to_char(a.entertime,'yyyy-mm-dd hh24:mi:ss') as "enterTime",
--    to_char(a.outtime,'yyyy-mm-dd hh24:mi:ss') as "outTime", s.name as "student name",o.teacherNum
--    from tblopenCourse o
--        inner join tblcourseHistory h
--            on o.num = h.openCourseNum
--                inner join tblattendance a
--                    on a.courseHistoryNum = h.num
--                        inner join tblstudent s
--                            on s.num = h.studentNum
--                                where o.status <> 1 and h.deletestatus <> 1 and s.deletestatus <> 1 and h.status <> '수료';
/*모든 출결 조회는 근태 상황을 구분할 수 있어야 한다.(정상, 지각, 조퇴(enter time이 나왔지만 outTime이 일찍), 외출, 병가(결석), 기타)*/
-- 년,월 동시에 받아서 정렬
-- 트리거로 자바에서 => 관리자
-- procteacherAttendanceStatus()
select * from tblcoursehistory order by num; --h: 16 o:1
select * from tblattendance;
select * from tblopenCourse;
create or replace procedure procteacherAttendanceStatus(
     presult out sys_refcursor,
     pyear varchar2,
     pmonth varchar2,
     pteacherNum number
   
)
is
begin   
open presult for 
    select s.name as "studentName",a.enterTime as "enterTime", a.outTime as "outTime",a.status as "attendanceStatus", h.opencoursenum as "openCourseNum" from tblattendance a
               inner join tblcourseHistory h
                            on h.num = a.courseHistoryNum 
                                 inner join tblstudent s
                                       on s.num = h.studentNum
                                            inner join tblopenCourse o
                                                on o.num = h.openCourseNum
                                                    where h.status <> '수료' and s.deletestatus <> 1 and h.deletestatus <> 1 and to_char(a.enterTime,'yyyy') = pyear and to_char(a.enterTime,'mm') = pmonth and o.teacherNum = pteacherNum and o.status <> 1;
end procteacherAttendanceStatus;

/*
select s.name as "student name",a.enterTime as "enterTime", a.outTime as "outTime",a.status as "attendance status", h.opencoursenum as "openCourseNum", o.teacherNum from tblattendance a
               inner join tblcourseHistory h
                            on h.num = a.courseHistoryNum 
                                 inner join tblstudent s
                                       on s.num = h.studentNum
                                            inner join tblopenCourse o
                                                on o.num = h.openCourseNum
                                                    where h.status <> '수료' and s.deletestatus <> 1 and h.deletestatus <> 1 and o.status <> 1 and  o.teacherNum = 1;
*/

select * from tblattendance;
