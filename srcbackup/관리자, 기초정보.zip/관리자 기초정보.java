package com.test.admin;

import java.util.Scanner;

public class AdminBasic {
	
	 void Bmenu() {
		while(true) {
		Scanner sc = new Scanner(System.in);
		System.out.println("〓〓〓〓〓〓〓〓〓〓〓기초데이터 관리〓〓〓〓〓〓〓〓〓〓〓");
		System.out.println("1.개설과정 관리"); //tblOpencourse
		System.out.println("2.개설과목 관리"); //tblSubjectByCourse
		System.out.println("3.강의실");	//tblClassroom
		System.out.println("4.과목");	//tblSubject
		System.out.println("5.과정");	//tblAllCourse
		System.out.println("6.교재"); 	//tblBook
		System.out.println("7.교육생");
		System.out.println("8.뒤로가기");
		System.out.println("〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓");
		System.out.print("▷입력:");
		String num = sc.nextLine();
		chan m1 = new chan();
		if(num.equals("1")) {
			//개설과정 관리
			while(true) {
				System.out.println("〓〓〓〓〓〓〓〓〓〓〓개설과정 관리〓〓〓〓〓〓〓〓〓〓");
				System.out.println("1. 강의 개설");
				System.out.println("2. 수정");
				System.out.println("3. 삭제");
				System.out.println("0. 뒤로가기");
				System.out.println("〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓");
				System.out.println("▷입력:");
				String room = sc.nextLine();
				if(room.equals("1")) {
					
					m1.procOpenCourseInsert();
				}
				else if(room.equals("2")) {
					m1.procOpenCourseUpdate();
				}
				else if(room.equals("3")) {
					m1.procOpenCourseDelete();
				}
				else if(room.equals("0")) {
				break;
				}
				else {
				System.out.println("잘못된 번호 입니다.");
				}
			  }
		}
		else if(num.equals("2")) {
			//개설과정 별 과목 목록 관리
			while(true) {
				System.out.println("〓〓〓〓〓〓〓〓〓〓〓개설과정 관리〓〓〓〓〓〓〓〓〓〓");
				System.out.println("1. 강의 개설");
				System.out.println("2. 수정");
				System.out.println("3. 삭제");
				System.out.println("0. 뒤로가기");
				System.out.println("〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓");
				System.out.println("▷입력:");
				String room = sc.nextLine();
				if(room.equals("1")) {
					//m1.procAddSubjectByCourse();
				}
				else if(room.equals("2")) {
					//m1.procUpdateSubjectByCourse();
				}
				else if(room.equals("3")) {
					//m1.procDeleteSubjectByCourse();
				}
				else if(room.equals("0")) {
				break;
				}
				else {
				System.out.println("잘못된 번호 입니다.");
				}
			  }
		}
		else if(num.equals("3")) {
			while(true) {
			//강의실 1.추가(insert) 2.수정(update) 3.삭제
			System.out.println("〓〓〓〓〓〓〓〓〓〓〓강의실 관리〓〓〓〓〓〓〓〓〓〓");
			System.out.println("1. 강의실 추가");
			System.out.println("2. 강의실 수정");
			System.out.println("3. 강의실 삭제");
			System.out.println("0. 뒤로가기");
			System.out.println("〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓");
			System.out.println("▷입력:");
			String room = sc.nextLine();
			if(room.equals("1")) {
			m1.procAddclassroom();
			}
			else if(room.equals("2")) {
			m1.procUpdateClassRoom();
			}
			else if(room.equals("3")) {
			m1.procdeleteclassroom();
			}
			else if(room.equals("0")) {
			break;
			}
			else {
			System.out.println("잘못된 번호 입니다.");
			}
		  }
		}
		else if(num.equals("4")) {
			while(true) {
			//1.추가 2.수정 3.삭제
			System.out.println("〓〓〓〓〓〓〓〓〓〓〓과목 관리〓〓〓〓〓〓〓〓〓〓〓");
			System.out.println("1. 과목 추가");
			System.out.println("2. 과목 수정");
			System.out.println("3. 과목 삭제");
			System.out.println("0. 뒤로가기");
			System.out.println("〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓");
			System.out.println("▷입력:");
			String room = sc.nextLine();
			if(room.equals("1")) {
			m1.procAddSubject();
			}
			else if(room.equals("2")) {
			m1.procUpdateSubject();
			}
			else if(room.equals("3")) {
			//procDeleteSubject();
			}
			else if(room.equals("0")) {
			break;
			}
			else {
			System.out.println("잘못된 번호 입니다.");
			}
			}
		}
		else if(num.equals("5")) {
			//1.추가 2.수정 3.삭제
			//1.추가 2.수정 3.삭제
			System.out.println("〓〓〓〓〓〓〓〓〓〓〓과정 관리〓〓〓〓〓〓〓〓〓〓");
			System.out.println("1. 과정 추가");
			System.out.println("2. 과정 수정");
			System.out.println("3. 과정 삭제");
			System.out.println("0. 뒤로가기");
			System.out.println("〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓");
			System.out.println("▷입력:");
			String room = sc.nextLine();
			if(room.equals("1")) {
			m1.procAddSubject();
			}
			else if(room.equals("2")) {
			m1.procUpdateSubject();	
			}
			else if(room.equals("3")) {
			//m1.procDeleteSubject();	
			}
			else if(room.equals("0")) {
			break;	
			}
			else {
			System.out.println("잘못된 번호 입니다.");
			}
		}
		else if(num.equals("6")) {
			//1.추가 2.수정 3.삭제
			//1.추가 2.수정 3.삭제
			System.out.println("〓〓〓〓〓〓〓〓〓〓〓교재 관리〓〓〓〓〓〓〓〓〓〓");
			System.out.println("1. 교재 추가");
			System.out.println("2. 교재 수정");
			System.out.println("3. 교재 삭제");
			System.out.println("0. 뒤로가기");
			System.out.println("〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓");
			System.out.println("▷입력:");
			String room = sc.nextLine();
			if(room.equals("1")) {
			m1.procAddBook();	
			}
			else if(room.equals("2")) {
			m1.procUpdateBook();	
			}
			else if(room.equals("3")) {
			//m1.procDeleteBook();	
			}
			else if(room.equals("0")) {
			break;
			}
			else {
			System.out.println("잘못된 번호 입니다.");
			}
		}
		else if(num.equals("0")) {
		break;
		}
		
		else if(num.equals("7")) {
			//1.추가 2.수정 3.삭제
			System.out.println("〓〓〓〓〓〓〓〓〓〓〓교육생 관리〓〓〓〓〓〓〓〓〓〓");
			System.out.println("1. 교육생 추가");
			System.out.println("2. 교육생 수정");
			System.out.println("3. 교육생 삭제");
			System.out.println("0. 뒤로가기");
			System.out.println("〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓");
			System.out.println("▷입력:");
			String room = sc.nextLine();
			if(room.equals("1")) {
			//procAddStudent();	
			}
			else if(room.equals("2")) {
			//procUpdateStudent();	
			}
			else if(room.equals("3")) {
			//procDeleteStudent();
			}
			else if(room.equals("0")) {
			break;
			}
			else {
			System.out.println("잘못된 번호 입니다.");
			}
		}
		else if(num.equals("0")) {
		break;
		}
		else {
		System.out.println("잘못된 번호입니다.");
		}
			}
		}
	}

