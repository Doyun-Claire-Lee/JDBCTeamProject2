/*** project_test_tblopenCourseManagement_admin ***/
select * from tblopenCourse;
/*특정 개설 과정 선택시 개설 과정에 등록된 개설 과목 정보(과목명, 과목기간(시작 년월일, 끝 년월일), 교재명, 교사명) 및 
등록된 교육생 정보(교육생 이름, 주민번호 뒷자리, 전화번호, 등록일, 수료 및 중도탈락)을 확인할 수 있어야 한다.*/
--select 
-- vwopenCourseSubject()
select * from tblopenCourse;
select * from tblcoursehistory;

delete tblopenCourse where num = 65;
drop view vwopenCourseSubject;

-- 뷰 추가
create or replace view vwopenCourseName
as
select o.num as openCourseNum, a.name as courseName from tblopenCourse o
    inner join tblAllCourse a
        on o.allCourseNum = a.num 
            where o.status <> 1 and a.deletestatus <> 1
                order by o.num;

create or replace view vwopenCourseSubject
as
select o.num,s.name as "subjectname",p.startDate || '~' || p.endDate as "Subject duration", b.name as "textbook name", t.name as "teacher name", st.name as "student name",substr(st.ssn,8) as "ssn",
st.tel as "tel",st.registerDate as "registration date",c.status as "completion status" from tblopenCourse o 
    inner join tblperiodBySubject p
        on p.openCourseNum = o.num
            inner join tblSubjectByCourse sc
                on sc.num = p.subjectByCourseNum
                    inner join tblSubject s
                        on s.num = sc.subjectNum
                            inner join tblBook b
                                on b.subjectNum = s.num
                                    inner join tblteacher t
                                    on t.num = o.teacherNum
                                        inner join tblcourseHistory c
                                           on c.openCourseNum = o.num
                                            inner join tblstudent st
                                                on st.num = c.studentnum
                                                    where o.status <> 1 and s.deletestatus <> 1 and t.deletestatus <> 1 and c.deletestatus <> 1 and st.deletestatus <> 1
                                                        order by o.num;

/*개설 과정 정보 출력시 개설 과정명, 개설 과정기간(시작 년월일, 끝 년월일), 강의실명, 개설 과목 등록 여부, 교육생 등록 인원을 출력한다.*/
--select 
-- vwopenCourseInfo()
create or replace view vwopenCourseInfo 
as
select o.num as "openCourseNum",a.name as "opening course name",o.startDate || '~' || o.endDate as "opening course period",c.name as "classroom name"
   ,decode((select distinct allCourseNum from tblSubjectByCourse where a.num = allCourseNum),null,'X','O')  as "register opening course"
   , (select count(*) from tblcourseHistory h where h.openCourseNum = o.num and h.status = '수강중' and h.deletestatus <> 1) as "trainee registration personnel"
from tblopenCourse o
    inner join  tblallCourse a
        on o.allCourseNum = a.num
             inner join tblclassRoom c
                 on o.classRoomNum = c.num
                    where o.status <> 1 and a.deletestatus <> 1
                        order by o.num; -- 조인을 했을때와 상관쿼리를 했을 때 미묘하게 달라 불필요하게 많으면 상관서브쿼리를 쓰는게 맞아
select * from vwopenCourseInfo;
/*과정 정보는 과정명, 과정기간(시작 년월일, 끝 년월일), 강의실 정보를 입력한다.*/
-- insert
-- procopenCourse()

select * from tblallCourse;
select * from tblopenCourse;
select * from tblopenCourse;

create or replace procedure procopenCourse(

    pstartDate varchar2,
    pendDate varchar2,
    pclassRoomNum tblopenCourse.classRoomNum%type,
    pallCourseNum tblopenCourse.allCourseNum%type
  
)
is
begin
    insert into tblopencourse(num,startDate,endDate,classRoomNum,allCourseNum,status) values(OPENCOURSESEQ.nextval,to_date(pstartDate,'yyyymmdd'),to_date(pendDate,'yyyymmdd'),pclassRoomNum,pallCourseNum,default);

end procopenCourse;

create or replace view vwclassRoom 
as 
select num as "classRoomNum", name as "classRoomName", capacity from tblclassroom where deletestatus <> 1 order by num;

create or replace view vwallCourse1 
as
select num as allCourseNum,name as courseName,capacity,period as coursePeriod from tblallCourse order by num;

-- 과정 정보 입력 부분
--insert

        
/*개설 과정 정보에 대한 입력, 출력, 수정, 삭제 기능을 사용할 수 있어야 한다.*/ 
-- insert,update,delete,select
-- 입력 insert
-- procopenCourseInsert()

-- pclassRoomNum하고 pteacherNum,pallCourseNum 보여줘야 될 듯 
-- tblclassRoom,tblopenCourse,tblallCourse
---- 넣을 수 있는 강의실 번호를 보여줌
select * from tblopenCourse;
select * from tblallCourse;
create or replace procedure procopenCourseInsert(

    pstartDate varchar2,
    pendDate varchar2,
    pclassRoomNum tblopenCourse.classRoomNum%type,
    pteacherNum tblopenCourse.teacherNum%type,
    pallCourseNum tblopenCourse.allCourseNum%type


)
is 
begin
    insert into tblopenCourse values(openCourseseq.nextVal,to_date(pstartDate,'yyyymmdd'),to_date(pendDate,'yyyymmdd'),pclassRoomNum,pteacherNum,pallCourseNum,default);

end procopenCourseInsert;

--추가
create or replace view vwteacher
as 
select t.num as teacherNum, s.name "availablesubjectName" from tblteacher t
    inner join tblavailablesubject a
        on t.num = a.teachernum
            inner join tblSubject s
                on s.num = a.subjectnum
                      where t.deletestatus <> 1 and s.deletestatus <> 1
                            order by teacherNum;

create or replace view vwallCourse
as
select a.num as "allCourseNum", a.name as "courseName", sc.period as "subjectPeriod", s.name as "subjectName",capacity, a.period as "coursePeriod" from tblallCourse a
    inner join tblsubjectbycourse sc
        on sc.allcoursenum = a.num
            inner join tblSubject s
                on s.num = sc.subjectnum
                    where a.deletestatus <> 1 and s.deletestatus <> 1 order by a.num,sc.period;

select * from tblallCourse;

-- 수정 시작
-- 시작날짜 수정(기존의 원래 가지고 있는걸 10개를 다 고치는 프로시저 나이만 고치면 나머지를 알아야 돼 나이만 새로운값)
-- update 하나 프로시저 모든 컬럼을 수정할 수 있어야 한다. 매개변수 10개 select 를 날려서 
-- select * from tblInsa where num = 1001;
-- update tblInsa set
-- 모든 정보를 수정하는 
-- num = 1001
-- name = '수정값'
-- ssn = 4564654-54616
-- ...
-- sudang = 20000
-- where num = ?
-- 자바 procUpdate('','','',..)

--select * from tblopenCourse num = 번호;
--select * from tblopenCourse where num = pnum; -- 커서 반환하는 프로시저, 매개변수 하나 pnum 

-- procopenCourseUpdate()
-- select,update
-- drop 해야 될 듯 vwopenCourseSelect

/*
drop view vwopenCourseSelect;
create or replace view vwopenCourseSelect
as 
select o.num as "openCourseNum", a.name as "openCourse name" from tblopenCourse o   
    inner join tblallCourse a
        on a.num = o.allCourseNum
            where o.status <> 1
                order by o.num;
*/       

create or replace procedure procopenCourseSelect(
    pnum tblopenCourse.num%type,
    presult out sys_refcursor
)
is
begin
    open presult for 
        select * from tblopenCourse where num = pnum and status <> 1;
end procopenCourseSelect;

select * from tblopenCourse;
commit;
create or replace procedure procopenCourseUpdate(
    pnum tblopenCourse.num%type,
    pstartDate varchar2,
    pendDate varchar2,
    pclassRoomNum tblopenCourse.classRoomNum%type,
    pteacherNum tblopenCourse.teacherNum%type,
    pallCourseNum tblopenCourse.allCourseNum%type

)
is 
begin 
    update tblopenCourse set startDate = to_date(pstartDate,'yyyymmdd'), endDate = to_date(pendDate,'yyyymmdd'), classRoomNum = pclassRoomNum, teacherNum = pteacherNum, allCourseNum = pallCourseNum, status = default where num = pnum;
    
end procopenCourseUpdate;

desc tblteacher;
desc tblopencourse;
-- 삭제 
-- procopenCourseDelete()
--update

create or replace procedure procopenCourseDelete(
    pnum tblopenCourse.num%type
)
is 
begin
  
   -- 상태값을 줘서 삭제된 얘인거를 표시를 해
   update tblopenCourse set status = 1 where num = pnum; 

end procopenCourseDelete;

select * from tblopenCourse;
rollback;

select * from tblopenCourse;
alter table tblopenCourse Add(status number(1));
alter table tblopenCourse Modify(status default 0 not null);
desc tblopencourse;

--update tblopenCourse set status = default where num = 12;

select * from tblopenCourse;

--출력
-- vwopenCourse()
--select 
create or replace view vwopenCourse
as 
select * from tblopenCourse where status <> 1 order by num;


/*특정 개설 과정이 수료한 경우 등록된 교육생 전체에 대해서 수료날짜를 지정할 수 있어야 한다. 단, 중도 탈락자는 제외한다. */
--update
-- vwopenCourseSelectEndDate()
create or replace view vwopenCourseSelectEndDate
as
select h.num as "courseHistoryNum", h.openCourseNum, h.status, s.name as "student name", h.endDate from tblcourseHistory h 
    inner join tblstudent s
        on s.num = h.studentnum
            where h.status = '수료' and h.deletestatus <> 1 and s.deleteStatus <> 1 order by h.num;

create or replace procedure procstudentEndDate(
    pendDate varchar2,
    pcourseHistoryNum tblcourseHistory.num%type
)
is 
begin
    update tblcourseHistory set enddate = to_date(pendDate,'yyyymmdd') where status = '수료' and status <> '중도탈락' and num = pcourseHistoryNum and deletestatus <> 1;

end procstudentEndDate;




/*강의실 정보는 기초 정보 강의실명에서 선택적으로 추가할 수 있어야 한다.*/ 
-- 개강하는 반에 6개 강의 중에 선택할 수 있는가? 강의실이 비워져 있을 때 선택, select가 필요 모든 강의실 비워있는 강의실만 보여주고
-- 이중에 어느 강의실로 할지 선택, 강의실이 안 정해져 있을 때, 기간도 봐야 돼, pnum PK , 강의실 번호 프로시저
-- 만들었고 확인만 하면 돼 
-- procBasicClassroom()
--select,update
select * from tblopenCourse;
select * from vwopenCourseInfo;
select * from tblcourseHistory;
select * from tblopenCourse;
insert into tblopenCourse values(40,'20/07/05','21/02/01',null,null,14,default);
commit;
create or replace view vwopenCourseClassRoom
as 
select o.num as "opening course number", o.startDate as "startDate", o.endDate as "endDate", o.classRoomNum as "classRoomNum" from tblopenCourse o
            where not sysdate between o.startDate and o.endDate and o.classRoomNum is null and o.status <> 1;

create or replace procedure procBasicClassroom(
    pnum tblopenCourse.num%type,
    pclassRoomNum tblopenCourse.classRoomNum%type
)
is 
begin
   
   update tblopenCourse set classRoomNum = pclassRoomNum where num = pnum and status <> 1;

end procBasicClassroom;


select * from tblopenCourse;

