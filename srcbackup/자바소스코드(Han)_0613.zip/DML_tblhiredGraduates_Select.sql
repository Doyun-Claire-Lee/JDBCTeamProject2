/*관리자는 수료생의 고용보험 여부를 조회 후 그 결과를 입력할 수 있다.*/

/*** project_test_tblhiredGraduates_Select.java ***/

-- 만약에 컬럼명이 as 할때 의미랑 같으면 꼭 as 해서 별칭을 붙일 필요는 없을까 함수 알아보기 어려운것만 함
-- prochiredGraduatesUpdate()
select * from tblhiredgraduates;


create or replace view vwhiredGraduatesSelect
as
select a.*, decode(status,'재직중','O','X') as "employment insurance", (select o.teacherNum from tblcourseHistory h
                                                                                    inner join tblopenCourse o
                                                                                      on o.num = h.openCourseNum
                                                                                            where a.courseHistoryNum = h.num and h.deletestatus <> 1 and o.status <> 1) as "teacherNum" from tblhiredGraduates a order by num;

create or replace PROCEDURE prochiredGraduatesUpdate(
    pnum tblhiredGraduates.num%type
)
is
begin
    update tblhiredgraduates set status = '재직중' where num = pnum;
end prochiredGraduatesUpdate;

/*추가적으로 회사이름과 연봉을 기입할 수 있다.(선택적)*/
-- prochiredGraduatesUpdate1()

select * from tblhiredgraduates;

create or replace view vwallCourse
as
select num as allCourseNum,name as courseName from tblallCourse  where deletestatus <> 1 order by num;

create or replace procedure prochiredGraduatesUpdateSelect(
    pnum tblhiredGraduates.num%type,
    presult out sys_refcursor
)
is
begin
    open presult for
        select * from tblhiredGraduates where num = pnum;
end prochiredGraduatesUpdateSelect;

create or replace procedure prochiredGraduatesUpdate1(
    pnum tblhiredGraduates.num%type,
    pcourseHistoryNum tblhiredGraduates.courseHistoryNum%type,
    pcompany tblhiredGraduates.company%type,
    psalary tblhiredGraduates.salary%type,
    pstatus tblhiredGraduates.status%type
)
is
begin
   update tblhiredgraduates set courseHistoryNum = pcourseHistoryNum,company = pcompany, salary = psalary,status = pstatus where num = pnum;
end prochiredGraduatesUpdate1;

/*관리자는 취업 완료 수료생 리스트 조회 시 연봉별 검색이 가능하다. */
-- prochiredgradesSalarySelect()
select * from tblhiredgraduates; 

create or replace PROCEDURE prochiredgradesSalarySelect(
    pstart number,
    pend number,
    presult out sys_refcursor
)
is
begin
     open presult for 
            select coursehistorynum,company,salary,status 
                            from tblhiredGraduates where salary between pstart and pend order by salary,coursehistorynum;
end prochiredgradesSalarySelect;

/*관리자가 취업 완료 수료생 관리를 할 수 있다. (추가,삭제,출력) */
-- 출력
-- vwhiredGradesManSelect()
select * from tblhiredgraduates;
create or replace view vwhiredGradesManSelect
as select num,courseHistoryNum,company,salary,status from tblhiredGraduates order by num;

-- 추가
-- prochiredGradesManInsert()
select * from tblhiredGraduates;
create or replace procedure prochiredGradesManInsert(
    pcourseHistoryNum tblhiredGraduates.courseHistorynum%type,
    pcompany tblhiredGraduates.company%type,
    psalary tblhiredGraduates.salary%type,
    pstatus tblhiredGraduates.status%type
)
is
begin
    insert into tblhiredGraduates values(hiredGraduatesseq.nextVal,pcourseHistoryNum,pcompany,psalary,pstatus);
end prochiredGradesManInsert;

--삭제 
-- prochiredGradesManDelete()
select * from tblhiredgraduates;
create or replace procedure prochiredGradesManDelete(
    pnum tblhiredGraduates.num%type
) 
is
begin
    delete tblhiredGraduates where num = pnum;
end prochiredGradesManDelete;

 /*관리자는 회사명으로 조회 가능*/
--prochiredGradesSelectName()
create or replace procedure prochiredGradesSelectName(
    pcompany tblhiredGraduates.company%type,
    presult out sys_refcursor
)
is
begin
    open presult for
        select * from tblhiredGraduates where replace(upper(company),' ','') like replace('%' || upper(pcompany) || '%',' ','');
end prochiredGradesSelectName;
