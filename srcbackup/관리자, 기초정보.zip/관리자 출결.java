package com.test.admin;

import java.util.Scanner;

public class AdminAttendanceM {

public void AttendanceCheck() {

	while(true) {
		chan m1 = new chan();
		Scanner sc = new Scanner(System.in);
		System.out.println("〓〓〓〓〓〓〓〓〓〓〓출결 관리〓〓〓〓〓〓〓〓〓〓〓");
		System.out.println("1. 학생별 출결 조회");
		System.out.println("2. 날짜별 출결 조회");
		System.out.println("3. 출결 내역 조회");
		System.out.println("0. 뒤로가기");
		System.out.println("〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓");
		System.out.print("▷입력:");
		String num = sc.nextLine();
		
		if(num.equals("1")) {
			m1.vwAllattendance();
		}
		else if(num.equals("2")) {
			m1.PROCPRINTATTENDANCEDATE();
		}
		else if(num.equals("3")) {
			m1.vwAllattendance();
		}
		else if(num.equals("0")) {
			System.out.println("뒤로가는 중...");
			break;
		}
		else {
			System.out.println("잘못된 번호 입력");
		}
	}
}
	
}
	