package com.test.admin;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Scanner;

import oracle.jdbc.OracleTypes;

public class AdminStudent {

	public static void main(String[] args) {
		
		AdminStudent adminstudent = new AdminStudent();
		adminstudent.mainMenu();
	}
	
	
	// 교육생 관리 메뉴
	public void  mainMenu() {

		Scanner scan = new Scanner(System.in);
		
	while (true) {	
		
		System.out.println("〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓");
		System.out.println("\t\t교육생 관리");
		System.out.println("〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓");
		System.out.println("1.취업 지원 관리");
		System.out.println("2.상담신청 및 일지 관리");
		System.out.println("3.성적 우수자 조회");
		System.out.println("4.보강 수업 대상자 조회");		
		System.out.println("0. 뒤로가기");
				
		System.out.println("〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓");
		System.out.print("▷ 입력:");
								
		// 사용자에게 번호 입력받음
		String cho = scan.nextLine();

			if (cho.equals("1")) {
				
				// 1.취업 지원 관리
				choNum1(scan);
				
			} else if (cho.equals("2")) {
				
				// 2.상담신청 및 일지관리
				choNum2(scan);
				
			
			} else if (cho.equals("3")) {
				
				// 3.성적 우수자
			
			} else if (cho.equals("4")) {
				
				// 4.보강 수업
			
				
			} else if (cho.equals("0")) {
				// 뒤로 가기
				System.out.println("뒤로가기를 선택하셨습니다.");
				System.out.println("엔터를 입력하시면 이전 페이지로 돌아갑니다.");
				scan.nextLine();
				break;
			} else {
				// 예외
				System.out.println("번호를 다시 입력해주세요");
			}
			
		}//while
				
	}//mainMenu()


//====================================================================================================
	
	
	// 1.취업 지원 관리
	private void choNum1(Scanner scan) {
		
		while(true) {
		
		System.out.println("〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓");
		System.out.println("\t취업 지원 관리 ");
		System.out.println("〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓");
		System.out.println("1. 취업 지원 내역 관리");
		System.out.println("2. 취업 활동 내역 관리");
		System.out.println("3. 취업 완료 수료생 관리");
		System.out.println("0. 뒤로가기");
		System.out.print("▷입력:");
		String cho = scan.nextLine();
		
		// 1.취업 지원 관리 -> 1.취업 지원 내역관리
		if(cho.equals("1")) {
			
			while(true) {
				
				System.out.println("〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓");
				System.out.println("\t취업 지원 내역 관리 ");
				System.out.println("〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓");
				System.out.println("1. 취업 지원 내역 입력");
				System.out.println("2. 취업 지원 내역 조회");			
				System.out.println("0. 뒤로가기");
				System.out.print("▷입력:");
				cho = scan.nextLine();
				
				if(cho.equals("1")) {
					
					// 취업 지원 내역 입력
					
				} else if(cho.equals("2")) {
				
					// 취업 활동 내역 조회
				
				} else if(cho.equals("0")) {					
					// 뒤로 가기
					System.out.println("뒤로가기를 선택하셨습니다.");
					System.out.println("엔터를 입력하시면 이전 페이지로 돌아갑니다.");
					scan.nextLine();
					break;			
				} else {					
					// 예외
					System.out.println("번호를 다시 입력해주세요");		
				}
				
				}//while(취업 지원 내역)
		
		// 1.취업 지원 관리-> 2.취업 활동 내역 관리	
		} else if(cho.equals("2")) {
			
			while(true) {
				
				System.out.println("〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓");
				System.out.println("\t취업 활동 내역 관리 ");
				System.out.println("〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓");
				System.out.println("1. 취업 활동 내역 조회(교육생별)");
				System.out.println("2. 취업 활동 내역 조회(강의별)");
				System.out.println("0. 뒤로가기");
				System.out.print("▷입력:");
				cho = scan.nextLine();
				
				if(cho.equals("1")) {
					
					// 취업 활동 내역 조회(교육생별)
					
				} else if(cho.equals("2")) {
					
					// 취업 활동 내역 조회(강의별)
				
				} else if(cho.equals("0")) {					
					// 뒤로 가기
					System.out.println("뒤로가기를 선택하셨습니다.");
					System.out.println("엔터를 입력하시면 이전 페이지로 돌아갑니다.");
					scan.nextLine();
					break;			
				} else {					
					// 예외
					System.out.println("번호를 다시 입력해주세요");		
				}
				
				}//while(취업 활동 내역 관리)
		
		// 1.취업지원 관리 -> 3.취업 완료 수료생 관리
		} else if(cho.equals("3")) {
			
			while(true) {
				
				System.out.println("〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓");
				System.out.println("\t취업 완료 수료생 관리 ");
				System.out.println("〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓");
				System.out.println("1. 취업 완료 수료생 조회");
				System.out.println("2. 취업 완료 수료생 수정");
				System.out.println("3. 취업 완료 수료생 삭제");
				System.out.println("4. 취업 완료 수료생 추가");
				System.out.println("0. 뒤로가기");
				System.out.print("▷입력:");
				cho = scan.nextLine();
				
				// 1.취업지원 관리 -> 3.취업 완료 수료생 관리 -> 1.취업 완료 수료생 조회
				if(cho.equals("1")) {
					
					// 취업 완료 수료생 조회
					while(true) {
						
						System.out.println("〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓");
						System.out.println("\t취업 완료 수료생 조회 ");
						System.out.println("〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓");
						System.out.println("1. 취업 완료 수료생 조회(전체)");
						System.out.println("2. 취업 완료 수료생 조회(연봉별)");
						System.out.println("3. 취업 완료 수료생 조회(회사별)");
						System.out.println("0. 뒤로가기");
						System.out.print("▷입력:");
						cho = scan.nextLine();
						
						if(cho.equals("1")) {
							
							// 취업 완료 수료생 조회(전체)
							
						} else if(cho.equals("2")) {
							
							// 취업 완료 수료생 조회(연봉별)
						
						} else if(cho.equals("3")) {
							
							// 취업 완료 수료생 조회(회사별)
						
						}else if(cho.equals("0")) {					
							// 뒤로 가기
							System.out.println("뒤로가기를 선택하셨습니다.");
							System.out.println("엔터를 입력하시면 이전 페이지로 돌아갑니다.");
							scan.nextLine();
							break;			
						} else {					
							// 예외
							System.out.println("번호를 다시 입력해주세요");		
						}
						
						}//while(취업완료 수료생 조회)
				
				// 1.취업지원 관리 -> 3.취업 완료 수료생 관리 -> 2.취업 완료 수료생 수정
				} else if(cho.equals("2")) {					
						
					// 취업 완료 수료생 수정
					while(true) {
						
						System.out.println("〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓");
						System.out.println("\t취업 완료 수료생 수정 ");
						System.out.println("〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓");
						System.out.println("1. 취업 완료 수료생 조회(고용보험)");
						System.out.println("2. 취업 완료 수료생 조회(연봉)");
						System.out.println("3. 취업 완료 수료생 조회(회사)");
						System.out.println("0. 뒤로가기");
						System.out.print("▷입력:");
						cho = scan.nextLine();
						
						if(cho.equals("1")) {
							
							// 취업 완료 수료생 수정(고용보험)
							
						} else if(cho.equals("2")) {
							
							// 취업 완료 수료생 수정(연봉)
						
						} else if(cho.equals("3")) {
							
							// 취업 완료 수료생 수정(회사)
						
						}else if(cho.equals("0")) {					
							// 뒤로 가기
							System.out.println("뒤로가기를 선택하셨습니다.");
							System.out.println("엔터를 입력하시면 이전 페이지로 돌아갑니다.");
							scan.nextLine();
							break;			
						} else {					
							// 예외
							System.out.println("번호를 다시 입력해주세요");		
						}
						
						}//while(취업 완료 수료생 수정)
				
				// 1.취업지원 관리 -> 3.취업 완료 수료생 관리 -> 3.취업 완료 수료생 삭제	
				} else if(cho.equals("3")) {					
					
					// 취업 완료 수료생 삭제
				
				// 1.취업지원 관리 -> 3.취업 완료 수료생 관리 -> 4.취업 완료 수료생 추가	
				} else if(cho.equals("4")) {					
					
					// 취업 완료 수료생 추가
					
				} else if(cho.equals("0")) {					
					// 뒤로 가기
					System.out.println("뒤로가기를 선택하셨습니다.");
					System.out.println("엔터를 입력하시면 이전 페이지로 돌아갑니다.");
					scan.nextLine();
					break;			
				} else {					
					// 예외
					System.out.println("번호를 다시 입력해주세요");		
				}
				
				}//while(취업 완료 수료생 관리)
			
				
		} else if(cho.equals("0")) {					
			 // 뒤로 가기
			  System.out.println("뒤로가기를 선택하셨습니다.");
			  System.out.println("엔터를 입력하시면 이전 페이지로 돌아갑니다.");
			  scan.nextLine();
			  break;			
		}
		else {					
			// 예외
			System.out.println("번호를 다시 입력해주세요");		
		}
		
		}//while(취업 지원 관리)
		
	}// 1.취업지원 관리 메뉴(끝)
	
	
//====================================================================================================
	
	
	// 2.상담신청 및 일지 관리
	private void choNum2(Scanner scan) {
		
		while (true) {	
			
			System.out.println("〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓");
			System.out.println("\t\t상담신청 및 일지 관리");
			System.out.println("〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓");
			System.out.println("1.상담신청 및 일지 조회(과정)");
			System.out.println("1.상담신청 및 일지 조회(학생)");
			System.out.println("0. 뒤로가기");
					
			System.out.println("〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓");
			System.out.print("▷ 입력:");
									
			// 사용자에게 번호 입력받음
			String cho = scan.nextLine();

				if (cho.equals("1")) {
					
					// 상담신청 및 일지 조회(과정)				
					
				} else if (cho.equals("2")) {
					
					// 상담신청 및 일지 조회(학생)					
		
				} else if (cho.equals("0")) {
					// 뒤로 가기
					System.out.println("뒤로가기를 선택하셨습니다.");
					System.out.println("엔터를 입력하시면 이전 페이지로 돌아갑니다.");
					scan.nextLine();
					break;
				} else {
					// 예외
					System.out.println("번호를 다시 입력해주세요");
				}
				
			}//while
		
	}// 2.상담신청 및 일지 관리(끝)
	
	
//====================================================================================================	
		

		
	
}//class
